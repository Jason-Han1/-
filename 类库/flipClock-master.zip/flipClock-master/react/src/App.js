import React from 'react';
import FlipClock from './components/FlipClock'

function App() {
  return (
    <div className="App">
      <FlipClock />
    </div>
  );
}

export default App;
