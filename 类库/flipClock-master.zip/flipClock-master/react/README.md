## 时钟翻牌Demo （React Version）

### 使用方法

#### 安装依赖包
```
npm install
```

#### 编译运行
```
npm start
```
