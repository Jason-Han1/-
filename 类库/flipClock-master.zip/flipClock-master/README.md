# flipClock
翻牌效果时钟的演示，包含原生JavaScript、Vue、React三种实现方式。

本Demo详细讲解请关注我的微信公众号，查阅文章《干货满满!如何优雅简洁地实现时钟翻牌器(支持JS/Vue/React)》

微信公众号：卧梅又闻花

头条号：卧梅又闻花

![avatar](https://user-gold-cdn.xitu.io/2019/11/25/16e9e56a1f75f0b9)
