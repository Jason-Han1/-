<template>
  <div id="app">
    <FlipClock></FlipClock>
  </div>
</template>

<script>
import FlipClock from './components/FlipClock.vue'

export default {
  name: 'app',
  components: {
    FlipClock
  }
}
</script>
